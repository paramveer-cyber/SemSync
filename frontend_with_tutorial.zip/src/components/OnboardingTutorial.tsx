import { useState, useEffect, useRef } from 'react';
import { X, ChevronRight, BookOpen, LayoutDashboard, BookMarked, CalendarDays, CheckSquare, Timer, ZoomIn } from 'lucide-react';

const STORAGE_KEY = 'semsync_tutorial_seen';

export function hasSeenTutorial(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) === 'true';
  } catch {
    return false;
  }
}

export function markTutorialSeen() {
  try {
    localStorage.setItem(STORAGE_KEY, 'true');
  } catch {}
}

export function resetTutorial() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {}
}

const STEPS = [
  {
    icon: ZoomIn,
    iconColor: '#f59e0b',
    title: 'Best Experience',
    subtitle: 'DISPLAY / ZOOM',
    body: 'SemSync is designed for 80% browser zoom. Press',
    kbd: ['Ctrl', '-', '(Windows)', 'or', 'Cmd', '-', '(Mac)'],
    tip: 'to zoom out until it feels right. You only need to do this once.',
    accent: 'rgba(245,158,11,0.15)',
    border: 'rgba(245,158,11,0.35)',
  },
  {
    icon: LayoutDashboard,
    iconColor: 'var(--color-brand)',
    title: 'Dashboard',
    subtitle: 'COMMAND CENTER',
    body: 'Your weekly focus lives here — all upcoming evaluations sorted by urgency. At a glance, know what\'s CRITICAL, OPERATIONAL, or ROUTINE.',
    kbd: null,
    tip: 'The week resets every Monday, automatically pulling your nearest deadlines.',
    accent: 'rgba(34,197,94,0.12)',
    border: 'rgba(34,197,94,0.3)',
  },
  {
    icon: BookMarked,
    iconColor: '#818cf8',
    title: 'Courses',
    subtitle: 'COURSE NODES',
    body: 'Add your courses and set a target grade. SemSync tracks your current grade vs target in real-time as you log evaluations.',
    kbd: null,
    tip: 'Each course node shows a live progress bar — green means you\'re on track.',
    accent: 'rgba(129,140,248,0.12)',
    border: 'rgba(129,140,248,0.3)',
  },
  {
    icon: CalendarDays,
    iconColor: '#38bdf8',
    title: 'Calendar',
    subtitle: 'TIMELINE VIEW',
    body: 'See all your evaluations plotted on a month-view calendar. Spot clashes before they happen and plan your study sprints.',
    kbd: null,
    tip: 'Click any evaluation on the calendar to jump straight to that course.',
    accent: 'rgba(56,189,248,0.12)',
    border: 'rgba(56,189,248,0.3)',
  },
  {
    icon: CheckSquare,
    iconColor: '#34d399',
    title: 'Task Center',
    subtitle: 'TO-DO SYSTEM',
    body: 'Break down your study load into actionable tasks. Link tasks to specific courses and evaluations to stay organised.',
    kbd: null,
    tip: 'Completed tasks are archived automatically — your history is always there.',
    accent: 'rgba(52,211,153,0.12)',
    border: 'rgba(52,211,153,0.3)',
  },
  {
    icon: Timer,
    iconColor: '#f472b6',
    title: 'Focus Timer',
    subtitle: 'POMODORO ENGINE',
    body: 'Built-in Pomodoro timer to lock in deep work sessions. Set your work interval and break time, then let the system keep you honest.',
    kbd: null,
    tip: 'Your session stats are tracked so you can see how much time you\'re putting in.',
    accent: 'rgba(244,114,182,0.12)',
    border: 'rgba(244,114,182,0.3)',
  },
];

interface OnboardingTutorialProps {
  onClose: () => void;
}

export default function OnboardingTutorial({ onClose }: OnboardingTutorialProps) {
  const [step, setStep] = useState(0);
  const [canProceed, setCanProceed] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [exiting, setExiting] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Reset countdown whenever step changes
  useEffect(() => {
    setCanProceed(false);
    setCountdown(3);

    timerRef.current = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setCanProceed(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [step]);

  const isLast = step === STEPS.length - 1;
  const current = STEPS[step];
  const Icon = current.icon;

  const handleNext = () => {
    if (!canProceed) return;
    if (isLast) {
      handleDone();
    } else {
      setStep(s => s + 1);
    }
  };

  const handleDone = () => {
    setExiting(true);
    setTimeout(() => {
      markTutorialSeen();
      onClose();
    }, 300);
  };

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center"
      style={{
        background: 'rgba(0,0,0,0.82)',
        backdropFilter: 'blur(8px)',
        WebkitBackdropFilter: 'blur(8px)',
        opacity: exiting ? 0 : 1,
        transition: 'opacity 0.3s ease',
      }}
    >
      {/* Card */}
      <div
        style={{
          width: '100%',
          maxWidth: 520,
          margin: '0 16px',
          background: 'var(--color-surface-1)',
          border: `1px solid ${current.border}`,
          borderRadius: 12,
          overflow: 'hidden',
          boxShadow: `0 0 60px ${current.accent}, 0 24px 60px rgba(0,0,0,0.6)`,
          transform: exiting ? 'scale(0.96) translateY(12px)' : 'scale(1) translateY(0)',
          transition: 'transform 0.3s ease, box-shadow 0.4s ease, border-color 0.4s ease',
        }}
      >
        {/* Top accent bar */}
        <div style={{ height: 3, background: `linear-gradient(90deg, ${current.iconColor}, transparent)` }} />

        {/* Header */}
        <div
          className="flex items-center justify-between px-6 py-4"
          style={{ borderBottom: '1px solid var(--color-glass-border)' }}
        >
          <div className="flex items-center gap-3">
            <div
              style={{
                width: 32, height: 32,
                borderRadius: 8,
                background: current.accent,
                border: `1px solid ${current.border}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <Icon style={{ width: 16, height: 16, color: current.iconColor }} />
            </div>
            <div>
              <p className="text-[10px] font-black tracking-[0.25em] uppercase" style={{ color: 'var(--color-text-faint)' }}>
                {current.subtitle}
              </p>
              <h2 className="text-base font-extrabold tracking-tight leading-none mt-0.5" style={{ color: 'var(--color-text)' }}>
                {current.title}
              </h2>
            </div>
          </div>

          {/* Step dots */}
          <div className="flex items-center gap-1.5">
            {STEPS.map((_, i) => (
              <div
                key={i}
                style={{
                  width: i === step ? 16 : 5,
                  height: 5,
                  borderRadius: 9999,
                  background: i === step ? current.iconColor : i < step ? 'var(--color-text-faint)' : 'var(--color-glass-border)',
                  transition: 'all 0.3s ease',
                }}
              />
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="px-6 py-6 space-y-4">
          <p className="text-[15px] leading-relaxed" style={{ color: 'var(--color-text-muted)' }}>
            {current.body}
            {current.kbd && (
              <>
                {' '}
                {current.kbd.map((k, i) =>
                  ['or', '(Windows)', '(Mac)'].includes(k) ? (
                    <span key={i} className="mx-0.5 text-xs" style={{ color: 'var(--color-text-faint)' }}>{k} </span>
                  ) : (
                    <kbd
                      key={i}
                      className="mx-0.5 px-1.5 py-0.5 text-xs font-bold rounded"
                      style={{
                        background: 'var(--color-surface-2)',
                        border: '1px solid var(--color-glass-border)',
                        color: 'var(--color-text)',
                        fontFamily: 'monospace',
                      }}
                    >
                      {k}
                    </kbd>
                  )
                )}
              </>
            )}
          </p>

          {/* Tip */}
          <div
            className="flex items-start gap-3 px-4 py-3 rounded-lg"
            style={{ background: current.accent, border: `1px solid ${current.border}` }}
          >
            <span className="text-base mt-0.5">💡</span>
            <p className="text-xs leading-relaxed" style={{ color: 'var(--color-text-muted)' }}>
              {current.tip}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div
          className="flex items-center justify-between px-6 py-4"
          style={{ borderTop: '1px solid var(--color-glass-border)', background: 'var(--color-glass)' }}
        >
          <span className="text-xs font-mono" style={{ color: 'var(--color-text-faint)' }}>
            {step + 1} / {STEPS.length}
          </span>

          <button
            onClick={handleNext}
            disabled={!canProceed}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 8,
              padding: '9px 20px',
              background: canProceed ? current.iconColor : 'var(--color-surface-2)',
              color: canProceed ? 'var(--color-surface)' : 'var(--color-text-faint)',
              border: canProceed ? `1px solid ${current.iconColor}` : '1px solid var(--color-glass-border)',
              borderRadius: 6,
              fontSize: 12,
              fontWeight: 800,
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              cursor: canProceed ? 'pointer' : 'not-allowed',
              transition: 'all 0.25s ease',
              minWidth: 120,
              justifyContent: 'center',
              boxShadow: canProceed ? `0 4px 14px ${current.accent}` : 'none',
            }}
          >
            {!canProceed ? (
              <>
                <span
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 18,
                    height: 18,
                    borderRadius: '50%',
                    border: `2px solid var(--color-glass-border)`,
                    borderTopColor: 'var(--color-text-faint)',
                    animation: 'spin 0.8s linear infinite',
                    fontSize: 10,
                    fontWeight: 900,
                  }}
                />
                {countdown}s
              </>
            ) : isLast ? (
              <>
                Done
                <span style={{ fontSize: 14 }}>✓</span>
              </>
            ) : (
              <>
                Next
                <ChevronRight style={{ width: 14, height: 14 }} />
              </>
            )}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
