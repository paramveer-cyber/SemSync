-- College Tracker — initial schema
-- Generated to match src/db/schema.js exactly

CREATE TABLE IF NOT EXISTS "users" (
    "id"         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "google_id"  TEXT NOT NULL UNIQUE,
    "email"      TEXT NOT NULL UNIQUE,
    "name"       TEXT NOT NULL,
    "avatar_url" TEXT,
    "created_at" TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS "courses" (
    "id"           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "user_id"      UUID NOT NULL REFERENCES "users"("id") ON DELETE CASCADE,
    "name"         TEXT NOT NULL,
    "credits"      INTEGER,
    "target_grade" REAL NOT NULL DEFAULT 50,
    "created_at"   TIMESTAMP DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS "evaluations" (
    "id"         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    "course_id"  UUID NOT NULL REFERENCES "courses"("id") ON DELETE CASCADE,
    "title"      TEXT NOT NULL,
    "type"       TEXT NOT NULL,
    "date"       TIMESTAMP NOT NULL,
    "weightage"  REAL NOT NULL,
    "max_score"  REAL NOT NULL,
    "score"      REAL,
    "created_at" TIMESTAMP DEFAULT now() NOT NULL
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS "idx_courses_user_id"      ON "courses"("user_id");
CREATE INDEX IF NOT EXISTS "idx_evaluations_course_id" ON "evaluations"("course_id");
CREATE INDEX IF NOT EXISTS "idx_evaluations_date"      ON "evaluations"("date");
